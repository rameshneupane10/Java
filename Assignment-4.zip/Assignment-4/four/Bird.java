public class Bird
{
    public int fly()
    {
        System.out.println("I am Flying");
    }
    public int walk()
    {
        System.out.println("I am Walking");
    }
}